CREATE TABLE locations (
    id INT PRIMARY KEY auto_increment,
    city VARCHAR(50),
    country VARCHAR(50),
    address VARCHAR(200),
    postal_code VARCHAR(20)
);


INSERT INTO locations (id, city, country, address, postal_code)
VALUES
    (1, 'New York', 'USA', '123 Main St', '10001'),
    (2, 'Seattle', 'USA', '654 Oak St', '98101'),
    (3, 'New York', 'USA', '789 Liberation St', '3701'),
    (4, 'Yerevan', 'Armenia', '10 Freedom Square', '0010'),
    (5, 'Berlin', 'Germany', '45 Friedrichstrasse', '10117'),
    (6, 'Berlin', 'Germany', '456 Freedom Ave', '375010'),
    (7, 'New York', 'USA', '987 Maple St', '94101');