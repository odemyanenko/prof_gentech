
CREATE TABLE departments (
    id INT PRIMARY KEY auto_increment,
    name VARCHAR(50),
    manager_id INT,
    location_id INT,
    budget DECIMAL(12, 2),
    phone_number VARCHAR(20)
);


INSERT INTO departments (id, name, manager_id, location_id, budget, phone_number)
VALUES
    (1, 'Sales', 1, 1, 500000, '555-123-4567'),
    (2, 'Marketing', 22, 2, 300000, '555-987-6543'),
    (3, 'Finance', 28, 3, 400000, '555-234-5678'),
    (4, 'Human Resources', 44, 4, 200000, '555-876-5432'),
    (5, 'Research and Development', 35, 5, 600000, '555-345-6789'),
    (6, 'IT', 22, 1, 450000, '555-654-3210'),
    (7, 'Operations', 49, 2, 350000, '555-789-0123'),
    (8, 'Customer Service', 22, 3, 250000, '555-210-9876'),
    (9, 'Supply Chain', 72, 4, 400000, '555-543-2109'),
    (10, 'Quality Assurance', 87, 5, 300000, '555-098-7654'),
    (11, 'Public Relations', 63, 1, 350000, '555-111-2222'),
    (12, 'Legal', 91, 2, 400000, '555-333-4444');

